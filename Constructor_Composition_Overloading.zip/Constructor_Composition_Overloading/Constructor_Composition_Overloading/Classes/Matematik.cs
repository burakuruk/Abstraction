﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructor_Composition_Overloading.Classes
{
    class Matematik
    {
            public int Topla(int a, int b)
            {
                return a + b;
            }

            public double Topla(double a, double b)
            {
                return a + b;
            }

            public int Topla(int a, int b, int c)
            {
                return a + b + c;
            }

            public int Carp(int a, int b)
            {
                return a * b;
            }

            public double Carp(double a, double b)
            {
                return a * b;
            }

            public int Carp(int a, int b, int c)
            {
                return a * b * c;
            }
    }
}
